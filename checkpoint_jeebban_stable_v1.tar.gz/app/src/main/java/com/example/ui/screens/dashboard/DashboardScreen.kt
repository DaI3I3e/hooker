package com.example.ui.screens.dashboard

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.EventNote
import androidx.compose.material.icons.filled.MailOutline
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.RemoveCircle
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.Savings
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Sms
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.AccountCard
import com.example.ui.components.BalanceCard
import com.example.ui.components.EmptyState
import com.example.ui.components.TransactionCard
import com.example.ui.theme.ExpenseColor
import com.example.ui.theme.IncomeColor
import com.example.ui.theme.TransferColor
import com.example.util.AmountFormatter

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    viewModel: DashboardViewModel,
    onNavigateToAddTransaction: (String) -> Unit,
    onNavigateToTransactions: () -> Unit,
    onNavigateToAccounts: () -> Unit,
    onNavigateToCategories: () -> Unit = {},
    onNavigateToDebts: () -> Unit = {},
    onNavigateToReports: () -> Unit = {},
    onNavigateToScanSms: () -> Unit = {},
    onNavigateToImportSms: () -> Unit = {},
    onNavigateToTransfer: () -> Unit = {},
    onNavigateToRecurring: () -> Unit = {},
    onNavigateToSavingsGoals: () -> Unit = {},
    onNavigateToCheques: () -> Unit = {},
    onNavigateToPlans: () -> Unit = {},
    onNavigateToSettings: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val summary by viewModel.uiState.collectAsStateWithLifecycle()
    var showMoreBottomSheet by remember { mutableStateOf(false) }
    val sheetState = rememberModalBottomSheetState()

    if (showMoreBottomSheet) {
        ModalBottomSheet(
            onDismissRequest = { showMoreBottomSheet = false },
            sheetState = sheetState
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 12.dp)
            ) {
                Text(
                    text = "سایر دسترسی‌ها",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(bottom = 16.dp)
                )

                // Row 1: انتقال، حساب‌ها، دسته‌بندی‌ها، بدهی و طلب
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    QuickAccessItem(
                        title = "انتقال",
                        icon = Icons.Default.SwapHoriz,
                        color = Color(0xFF1E88E5),
                        onClick = {
                            showMoreBottomSheet = false
                            onNavigateToTransfer()
                        },
                        modifier = Modifier.weight(1f)
                    )
                    QuickAccessItem(
                        title = "حساب‌ها",
                        icon = Icons.Default.AccountBalanceWallet,
                        color = Color(0xFF1976D2),
                        onClick = {
                            showMoreBottomSheet = false
                            onNavigateToAccounts()
                        },
                        modifier = Modifier.weight(1f)
                    )
                    QuickAccessItem(
                        title = "دسته‌بندی‌ها",
                        icon = Icons.Default.Category,
                        color = Color(0xFF8E24AA),
                        onClick = {
                            showMoreBottomSheet = false
                            onNavigateToCategories()
                        },
                        modifier = Modifier.weight(1f)
                    )
                    QuickAccessItem(
                        title = "بدهی و طلب",
                        icon = Icons.Default.ReceiptLong,
                        color = Color(0xFFFB8C00),
                        onClick = {
                            showMoreBottomSheet = false
                            onNavigateToDebts()
                        },
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Row 2: برنامه‌ها، گزارش‌ها، تنظیمات
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    QuickAccessItem(
                        title = "برنامه‌ها",
                        icon = Icons.Default.EventNote,
                        color = Color(0xFF00897B),
                        onClick = {
                            showMoreBottomSheet = false
                            onNavigateToPlans()
                        },
                        modifier = Modifier.weight(1f)
                    )
                    QuickAccessItem(
                        title = "گزارش‌ها",
                        icon = Icons.Default.BarChart,
                        color = Color(0xFF388E3C),
                        onClick = {
                            showMoreBottomSheet = false
                            onNavigateToReports()
                        },
                        modifier = Modifier.weight(1f)
                    )
                    QuickAccessItem(
                        title = "تنظیمات",
                        icon = Icons.Default.Settings,
                        color = Color(0xFF757575),
                        onClick = {
                            showMoreBottomSheet = false
                            onNavigateToSettings()
                        },
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(modifier = Modifier.weight(1f))
                }
                Spacer(modifier = Modifier.height(28.dp))
            }
        }
    }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // App Header (Top Bar with only Settings icon)
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "جیب‌بان",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                IconButton(onClick = onNavigateToSettings) {
                    Icon(
                        imageVector = Icons.Default.Settings,
                        contentDescription = "تنظیمات",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // Total Balance
        item {
            BalanceCard(totalBalance = summary.totalBalance)
        }

        // Today Summary Cards
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                TodaySummaryCard(
                    title = "درآمد امروز",
                    amount = summary.todayIncome,
                    color = IncomeColor,
                    isIncome = true,
                    modifier = Modifier.weight(1f)
                )
                TodaySummaryCard(
                    title = "هزینه امروز",
                    amount = summary.todayExpense,
                    color = ExpenseColor,
                    isIncome = false,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Quick Access (دسترسی سریع) 4 Icons
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                ),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 10.dp)
                ) {
                    Text(
                        text = "دسترسی سریع",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    // 5 Icons: ثبت هزینه | ثبت درآمد | اسکن پیامک | ورود پیامک | سایر
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        QuickAccessItem(
                            title = "ثبت هزینه",
                            icon = Icons.Default.RemoveCircle,
                            color = Color(0xFFE53935),
                            onClick = { onNavigateToAddTransaction("EXPENSE") },
                            modifier = Modifier.weight(1f)
                        )
                        QuickAccessItem(
                            title = "ثبت درآمد",
                            icon = Icons.Default.AddCircle,
                            color = Color(0xFF43A047),
                            onClick = { onNavigateToAddTransaction("INCOME") },
                            modifier = Modifier.weight(1f)
                        )
                        QuickAccessItem(
                            title = "اسکن پیامک",
                            icon = Icons.Default.Sms,
                            color = Color(0xFF00ACC1),
                            onClick = onNavigateToScanSms,
                            modifier = Modifier.weight(1f)
                        )
                        QuickAccessItem(
                            title = "ورود پیامک",
                            icon = Icons.Default.MailOutline,
                            color = Color(0xFFE91E63),
                            onClick = onNavigateToImportSms,
                            modifier = Modifier.weight(1f)
                        )
                        QuickAccessItem(
                            title = "سایر",
                            icon = Icons.Default.MoreHoriz,
                            color = Color(0xFF757575),
                            onClick = { showMoreBottomSheet = true },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        // Phase 3 Shortcuts: اقساط و دوره‌ای، اهداف پس‌انداز، چک صیادی
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Phase3ShortcutCard(
                    title = "اقساط و دوره‌ای",
                    subtitle = "تعهدات منظم",
                    icon = Icons.Default.Repeat,
                    color = Color(0xFF0288D1),
                    onClick = onNavigateToRecurring,
                    modifier = Modifier.weight(1f)
                )
                Phase3ShortcutCard(
                    title = "اهداف پس‌انداز",
                    subtitle = "قلک و پس‌انداز",
                    icon = Icons.Default.Savings,
                    color = Color(0xFF00897B),
                    onClick = onNavigateToSavingsGoals,
                    modifier = Modifier.weight(1f)
                )
                Phase3ShortcutCard(
                    title = "چک صیادی",
                    subtitle = "دریافتی/پرداختی",
                    icon = Icons.Default.ReceiptLong,
                    color = Color(0xFF7B1FA2),
                    onClick = onNavigateToCheques,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Accounts Header & Horizontal List
        item {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "حساب‌های من",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    TextButton(onClick = onNavigateToAccounts) {
                        Text("مشاهده همه", color = MaterialTheme.colorScheme.primary)
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                if (summary.accounts.isEmpty()) {
                    Text(
                        text = "هیچ حسابی تعریف نشده است",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                } else {
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(summary.accounts, key = { it.account.id }) { acc ->
                            AccountCard(accountWithBalance = acc)
                        }
                    }
                }
            }
        }

        // Recent Transactions Header & List
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "تراکنش‌های اخیر",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                TextButton(onClick = onNavigateToTransactions) {
                    Text("مشاهده همه", color = MaterialTheme.colorScheme.primary)
                }
            }
        }

        if (summary.recentTransactions.isEmpty()) {
            item {
                EmptyState(
                    title = "هنوز تراکنشی ثبت نشده است",
                    buttonText = "ثبت اولین تراکنش",
                    onButtonClick = { onNavigateToAddTransaction("EXPENSE") }
                )
            }
        } else {
            items(summary.recentTransactions.take(5), key = { it.transaction.id }) { tx ->
                TransactionCard(transactionWithDetails = tx)
            }
        }
    }
}

@Composable
fun QuickAccessItem(
    title: String,
    icon: ImageVector,
    color: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 4.dp, horizontal = 2.dp)
    ) {
        Box(
            modifier = Modifier
                .size(44.dp)
                .clip(CircleShape)
                .background(color.copy(alpha = 0.15f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = color,
                modifier = Modifier.size(22.dp)
            )
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = title,
            style = MaterialTheme.typography.labelSmall.copy(
                fontSize = 10.sp,
                lineHeight = 13.sp
            ),
            fontWeight = FontWeight.Medium,
            textAlign = TextAlign.Center,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}

@Composable
fun TodaySummaryCard(
    title: String,
    amount: Long,
    color: Color,
    isIncome: Boolean,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .height(76.dp)
            .shadow(
                elevation = 2.dp,
                shape = RoundedCornerShape(16.dp),
                spotColor = color.copy(alpha = 0.2f)
            ),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(CircleShape)
                    .background(color.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (isIncome) Icons.Default.ArrowUpward else Icons.Default.ArrowDownward,
                    contentDescription = title,
                    tint = color,
                    modifier = Modifier.size(22.dp)
                )
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = AmountFormatter.format(amount),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = color,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
fun QuickActionButton(
    title: String,
    color: Color,
    icon: ImageVector,
    onClick: () -> Unit
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.90f else 1.0f,
        label = "quickActionScale"
    )

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .scale(scale)
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                onClick = onClick
            )
            .padding(8.dp)
    ) {
        Box(
            modifier = Modifier
                .size(56.dp)
                .shadow(
                    elevation = 6.dp,
                    shape = CircleShape,
                    spotColor = color.copy(alpha = 0.5f)
                )
                .clip(CircleShape)
                .background(color),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = Color.White,
                modifier = Modifier.size(28.dp)
            )
        }
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = title,
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}

@Composable
private fun Phase3ShortcutCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    color: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .clickable { onClick() },
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp, horizontal = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .clip(CircleShape)
                    .background(color.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = color,
                    modifier = Modifier.size(20.dp)
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = subtitle,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
                fontSize = 10.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}


